package q1;

public interface Ablity {
	public void able();
}
