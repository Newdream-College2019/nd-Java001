package q1;

public class Progamer extends People implements Ablity{

	@Override
	public void able() {
		// TODO Auto-generated method stub
		System.out.println("�һ�д����");
	}
	
}
