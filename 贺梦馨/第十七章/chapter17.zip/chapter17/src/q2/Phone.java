package q2;

public interface Phone {
	public void function();
}
