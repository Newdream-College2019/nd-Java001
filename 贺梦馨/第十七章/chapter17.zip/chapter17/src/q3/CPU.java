package q3;

public interface CPU {
	String cpu=null;
	public String getCPUBrand();
	
	public Float getFrequency();
}
