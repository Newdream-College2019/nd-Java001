package q3;


public class Computer {
	CPU cpu;
	EMS ems;
	HardDisk hardDisk;
	
	public Computer(CPU cpu,EMS ems,HardDisk hardDisk){
		this.cpu=cpu;
		this.ems=ems;
		this.hardDisk=hardDisk;
	}
	
	public void showInfo(){
		System.out.println("���������Ϣ���£�CPU��Ʒ���ǣ�"+this.getCpu().getCPUBrand()+"��Ƶ�ǣ�"+this.getCpu().getFrequency()+"Ӳ��������"+getEms().getSize()+"�ڴ�������"+getHardDisk().getCapacity()+"\n\n");
	}

	public CPU getCpu() {
		return cpu;
	}

	public void setCpu(CPU cpu) {
		this.cpu = cpu;
	}

	public EMS getEms() {
		return ems;
	}

	public void setEms(EMS ems) {
		this.ems = ems;
	}

	public HardDisk getHardDisk() {
		return hardDisk;
	}

	public void setHardDisk(HardDisk hardDisk) {
		this.hardDisk = hardDisk;
	}
}
