package q3;

public interface EMS {
	public int getSize();
}
