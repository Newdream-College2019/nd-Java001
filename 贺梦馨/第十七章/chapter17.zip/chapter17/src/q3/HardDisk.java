package q3;

public interface HardDisk {
	public int getCapacity();
}
