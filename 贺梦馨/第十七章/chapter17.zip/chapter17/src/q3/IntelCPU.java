package q3;

public class IntelCPU implements CPU {

	@Override
	public String getCPUBrand() {
		// TODO Auto-generated method stub
		return "Intel";
	}

	@Override
	public Float getFrequency() {
		// TODO Auto-generated method stub
		return 3.8F;
	}

}
