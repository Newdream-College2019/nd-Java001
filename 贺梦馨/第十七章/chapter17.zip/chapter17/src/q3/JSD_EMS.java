package q3;

public class JSD_EMS implements EMS {

	@Override
	public int getSize() {
		// TODO Auto-generated method stub
		return 500;
	}

}
