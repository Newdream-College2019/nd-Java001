package q3;

public class XJ_HardDisk implements HardDisk {

	@Override
	public int getCapacity() {
		// TODO Auto-generated method stub
		return 4;
	}

}
