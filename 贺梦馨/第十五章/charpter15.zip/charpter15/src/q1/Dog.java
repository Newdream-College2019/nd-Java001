package q1;

public class Dog extends Pet{
	private String strain;
	public String getStrain() {
		return strain;
	}
	public void setStrain(String strain) {
		this.strain = strain;
	}
}
