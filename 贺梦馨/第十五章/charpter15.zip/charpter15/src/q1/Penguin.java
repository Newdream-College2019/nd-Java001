package q1;

public class Penguin extends Pet{
	private String sex;
	final String SEX_MALE="Q��";
	final String SEX_FEMALE="Q��";
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}

}
