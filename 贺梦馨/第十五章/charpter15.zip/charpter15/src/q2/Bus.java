package q2;

import java.util.Scanner;


public class Bus extends MotoVehicle{

	public Bus(String brand) {
		super(brand);
		// TODO Auto-generated constructor stub
	}
		// TODO Auto-generated constructor stub

	}