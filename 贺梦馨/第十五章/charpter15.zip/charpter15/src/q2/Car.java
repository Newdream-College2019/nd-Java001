package q2;

import java.util.Scanner;


public class Car extends MotoVehicle{
	public Car(String brand) {
		super(brand);
		// TODO Auto-generated constructor stub
	}

	final String type="�γ�";
	
}
