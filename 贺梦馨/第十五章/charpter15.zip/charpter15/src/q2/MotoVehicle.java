package q2;

public abstract class MotoVehicle {
	private String brand;
	private final String num="��A8888";
	private int price;
	int totalPrice;
	public MotoVehicle(String brand){
		this.brand=brand;
	}
	
	
	public String getBrand() {
		return brand;
	}


	public void setBrand(String brand) {
		this.brand = brand;
	}


	public String getNum() {
		return num;
	}


	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	public int CalaRent(int days){
		totalPrice=price*days;
		return totalPrice;
	}
	
}
