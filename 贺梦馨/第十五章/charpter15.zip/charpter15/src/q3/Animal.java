package q3;

public abstract class Animal {
	String type;
	String spacial;
	int age;
	
	public abstract void info();
}
