package q3;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bird bird=new Bird();
		bird.info();
		Fish fish=new Fish();
		fish.info();
	}

}
