package q1q2;

public class Penguin {
	String name;
	int love;
	int health;
	String sex;
	final String SEX_MALE="Q��";
	final String SEX_FEMALE="Q��";
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getLove() {
		return love;
	}
	public void setLove(int love) {
		this.love = love;
	}
	public int getHealth() {
		return health;
	}
	public void setHealth(int health) {
		if(1<health&&health<=100){
		this.health = health;
		}else{
			System.out.println(this.name+"�Ľ���ֵ��������");
		}
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}

}
