package q3;

public class Student1 {
	String name;
	int age;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		if(age<15){
			this.age=18;
		}else{
		this.age = age;}
		
	}
	
	public void interduce(){
		System.out.println("������"+name+"���䣺"+age);
	}
	
}
