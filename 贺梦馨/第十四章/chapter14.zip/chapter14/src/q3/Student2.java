package q3;

public class Student2 {
	String name;
	int age;
	String sex;
	String major;
	public Student2(String name,int age){
		this.name=name;
		this.age=age;
		this.sex="��";
		this.major="��������";
	}
	public Student2(String name,int age,String sex,String major){
		this.name=name;
		this.age=age;
		this.sex=sex;
		this.major=major;
	}
	public String getName(String name) {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public void interduce(){
		System.out.println("������"+name+"  ���䣺"+age+"  �Ա�"+sex+"  רҵ:"+major);
	}
}
