package q4;

public class Teacher {
	String name;
	String sex;
	int age;
	String major;
	final String JAVA="java";
	final String TEST="����";
	final String ANDROID="��׿";
	public Teacher(int age,String name){
		this.name=name;
		this.age=age;
		this.sex="��";
		this.major="��������";
	}
	public Teacher(String name,int age,String sex,String major){
		this.name=name;
		this.age=age;
		this.sex=sex;
		this.major=major;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	
	public void intreduce(){
		System.out.println("������"+name+"  ���䣺"+age+"  �Ա�"+sex+"  רҵ:"+major);
	}
}
