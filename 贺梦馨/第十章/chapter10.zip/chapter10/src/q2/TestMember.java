package q2;

import java.util.Scanner;

public class TestMember {
	Member member;
public void getScore(){
	Scanner in=new Scanner(System.in);
	System.out.print("��������֣�");
	int score=in.nextInt();
	System.out.print("�����뿨�����ͣ�");
	String card=in.next();
	Member member=new Member();
	member.getScore(card,score);
}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestMember test=new TestMember();
		test.getScore();
	}

}
