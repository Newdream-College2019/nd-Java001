package q4;

public class Calculator {
	double a;
	double b;
	int cal=1;
	
	public double calculat(double a,double b,int cal){
		double result=0;
	switch(cal){
	case 1:
		//System.out.println((a+b));
		result=a+b;
		return result;
	case 2:
		result=a-b;
		return result;
	case 3:
		result=a*b;
		return result;
	case 4:
		result=a/b;
		return result;
	default:
		return result;
	}
	}
}
