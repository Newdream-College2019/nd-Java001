package q5q6;

public class Demo {
	Time time;
	public void chage(){
		Time time =new Time();
		time.year=2015;
		time.month=5;
		time.day=12;
		time.hour=10;
		time.min=11;
		time.second=30;
	}
	
	
}
