package q5q6;

public class TestTime {
	Time time;
	Demo demo;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Time time =new Time();
		time.year=2015;
		time.month=5;
		time.day=12;
		time.hour=10;
		time.min=11;
		time.second=00;
		time.show();
		Demo demo =new Demo();
		demo.chage();
		time.show();
	}

}
