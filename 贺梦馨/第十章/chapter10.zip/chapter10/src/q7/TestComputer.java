package q7;

public class TestComputer {
	Computer conputer;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Computer computer=new Computer();
		computer.cpu="cpu";
		computer.xianshi="��ʾ��";
		computer.zhu="����";
		computer.yingpan="Ӳ��";
		computer.neicun="�ڴ�";
	}

}
